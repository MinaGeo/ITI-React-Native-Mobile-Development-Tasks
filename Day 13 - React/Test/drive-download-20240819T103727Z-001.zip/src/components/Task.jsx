import { Component } from "react";

class Task extends Component{

    constructor(){
        super();
        // console.log(props);
        this.state={x:4,task:{title:"React" , completed:false}}
    }
    // state={task:{title:"React" , completed:false}}
    render(){
     return <div>Task of {this.state.task.title} ,  {this.state.task.completed?"Done " :"inprogress"} <br>
     </br>
     {this.props.test}
     </div>
    }
}
export default Task;